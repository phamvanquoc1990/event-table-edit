DROP TABLE IF EXISTS `#__eventtableedit_details`;
DROP TABLE IF EXISTS `#__eventtableedit_heads`;
DROP TABLE IF EXISTS `#__eventtableedit_dropdowns`;
DROP TABLE IF EXISTS `#__eventtableedit_dropdown`;
